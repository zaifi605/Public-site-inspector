import unittest
from site_inspector.core import normalize_base_url

class URLTests(unittest.TestCase):
    def test_adds_https(self): self.assertEqual(normalize_base_url('example.com'), 'https://example.com/')
    def test_strips_path(self): self.assertEqual(normalize_base_url('https://example.com/path?q=1'), 'https://example.com/')
    def test_rejects_invalid(self):
        with self.assertRaises(ValueError): normalize_base_url('not a url ///')

if __name__ == '__main__': unittest.main()
