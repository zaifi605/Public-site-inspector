from urllib.parse import urljoin, urlparse
import xml.etree.ElementTree as ET
import requests

USER_AGENT = 'PublicSiteInspector/1.0 (responsible metadata checker)'

def normalize_base_url(url: str) -> str:
    candidate = url.strip()
    if not candidate:
        raise ValueError('Please provide a website URL.')
    if '://' not in candidate:
        candidate = 'https://' + candidate
    parsed = urlparse(candidate)
    if parsed.scheme not in {'http', 'https'} or not parsed.netloc or any(ch.isspace() for ch in parsed.netloc):
        raise ValueError('Enter a valid http:// or https:// URL.')
    return f'{parsed.scheme}://{parsed.netloc}/'

def _get(url: str, timeout: int = 8):
    return requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=timeout, allow_redirects=True)

def inspect_site(url: str, timeout: int = 8) -> dict:
    base = normalize_base_url(url)
    robots_url = urljoin(base, 'robots.txt')
    result = {'input_url': url, 'base_url': base, 'robots_url': robots_url, 'robots_status': None,
              'robots_found': False, 'robots_text': '', 'sitemaps': [], 'sitemap_candidates': [], 'notes': []}
    try:
        response = _get(robots_url, timeout)
        result['robots_status'] = response.status_code
        if response.status_code == 200:
            result['robots_found'] = True
            result['robots_text'] = response.text[:20000]
            for line in response.text.splitlines():
                if line.strip().lower().startswith('sitemap:'):
                    value = line.split(':', 1)[1].strip()
                    if value:
                        result['sitemap_candidates'].append(value)
        else:
            result['notes'].append(f'robots.txt returned HTTP {response.status_code}.')
    except requests.RequestException as exc:
        result['notes'].append(f'Could not fetch robots.txt: {type(exc).__name__}.')
    candidates = result['sitemap_candidates'] + [urljoin(base, 'sitemap.xml'), urljoin(base, 'sitemap_index.xml')]
    seen = set()
    for sitemap_url in candidates:
        if sitemap_url in seen:
            continue
        seen.add(sitemap_url)
        try:
            response = _get(sitemap_url, timeout)
            if response.status_code != 200:
                continue
            root = ET.fromstring(response.content)
            kind = root.tag.rsplit('}', 1)[-1].lower()
            if kind not in {'urlset', 'sitemapindex'}:
                continue
            locs = [e.text.strip() for e in root.iter() if e.tag.rsplit('}', 1)[-1].lower() == 'loc' and e.text]
            result['sitemaps'].append({'url': sitemap_url, 'type': kind, 'locations_found': len(locs), 'sample_locations': locs[:5]})
        except (requests.RequestException, ET.ParseError):
            continue
    if not result['sitemaps']:
        result['notes'].append('No valid sitemap was found at discovered common locations.')
    result['notes'].append('Checks public metadata endpoints only. Review robots.txt and site terms before crawling pages.')
    return result
