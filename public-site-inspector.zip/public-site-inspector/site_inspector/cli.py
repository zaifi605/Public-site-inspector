import argparse, json, sys
from .core import inspect_site

def main():
    parser = argparse.ArgumentParser(description='Inspect public robots.txt and sitemap metadata.')
    parser.add_argument('url', help='Website URL, e.g. https://example.com')
    parser.add_argument('--timeout', type=int, default=8, help='Request timeout in seconds')
    parser.add_argument('--output', '-o', help='Write JSON report to a file')
    args = parser.parse_args()
    try:
        report = inspect_site(args.url, args.timeout)
    except ValueError as exc:
        print(f'Error: {exc}', file=sys.stderr); raise SystemExit(2)
    data = json.dumps(report, indent=2, ensure_ascii=False)
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f: f.write(data + '\n')
        print(f'Report saved to {args.output}')
    else: print(data)

if __name__ == '__main__': main()
