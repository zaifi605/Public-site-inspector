# Public Site Inspector

A small open-source Python CLI that checks a website's public `robots.txt` and common XML sitemap endpoints. Built for learning responsible web research and scraping preparation.

## Features
- Accepts a domain or full HTTP(S) URL.
- Checks `/robots.txt` and reads `Sitemap:` declarations.
- Checks common sitemap endpoints (`sitemap.xml`, `sitemap_index.xml`).
- Validates XML sitemap structure and counts `<loc>` entries.
- Outputs JSON to the terminal or a file.
- Includes unit tests.

## Requirements
Python 3.9+ and internet access for live inspection.

## Install
```bash
git clone https://github.com/YOUR-USERNAME/public-site-inspector.git
cd public-site-inspector
python -m pip install -r requirements.txt
```

## Usage
```bash
python -m site_inspector https://example.com
python -m site_inspector example.com --output report.json
python -m site_inspector https://example.com --timeout 12
python -m unittest discover -s tests -v
```

## Responsible use
This project checks public metadata endpoints only. It does not bypass authentication, CAPTCHAs, rate limits, or access controls, and it does not crawl every URL listed in a sitemap. Read a site's `robots.txt`, terms, and applicable law before crawling. Use modest timeouts and request rates.

## License
MIT. See `LICENSE`.
